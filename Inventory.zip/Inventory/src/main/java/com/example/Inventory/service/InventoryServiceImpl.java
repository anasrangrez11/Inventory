package com.example.Inventory.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.Inventory.dto.InventryDto;
import com.example.Inventory.entity.InventryEntity;
import com.example.Inventory.repository.InventryRepo;

@Service
public class InventoryServiceImpl implements InventoryService{

	@Autowired
	InventryRepo inventryRepo;



	@Override
	public Object saveUpdateUser(InventryDto inventryDTO) {
		InventryEntity inventry = new InventryEntity();
		
		inventry.setName(inventryDTO.getName());
		inventry.setAddress(inventryDTO.getAddress());
		inventry.setPhonenumber(inventryDTO.getPhonenumber());
		
		inventryRepo.save(inventry);
	
		return inventry;
	}



	@Override
	public InventryDto getUserDetailsById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public ResponseEntity<List<InventryEntity>> getUsers() {
		
	List<InventryEntity> findAll = inventryRepo.findAll();
	
	
		
		return new ResponseEntity<List<InventryEntity>>(findAll,HttpStatus.OK);
	}



	@Override
	public Boolean deleteUserById(Long id) {

		
		
		if(inventryRepo.existsById(id)) {
			inventryRepo.deleteById(id);
			return true;
		}
		
		return false;
	}


	@Override
	public Boolean updateUserById(Long Id , InventryDto inventryDTO) {

		
		Optional<InventryEntity> findById = inventryRepo.findById(Id);
		
		if(findById.isPresent()) {
			
		InventryEntity inventryEntity = findById.get();
		
		
		
		inventryEntity.setAddress(inventryDTO.getAddress());
		inventryEntity.setName(inventryDTO.getName());
		inventryEntity.setPhonenumber(inventryDTO.getPhonenumber());
		
		
		inventryRepo.save(inventryEntity);
		return true;
		}
		return false;
	}
	



	
	
}
