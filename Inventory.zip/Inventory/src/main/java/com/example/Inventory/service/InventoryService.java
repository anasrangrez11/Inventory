package com.example.Inventory.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.Inventory.dto.InventryDto;
import com.example.Inventory.entity.InventryEntity;

public interface InventoryService  {
	
	public InventryDto getUserDetailsById(Long id);

	public Object saveUpdateUser(InventryDto inventryDTO);

	public ResponseEntity<List<InventryEntity>> getUsers();

	public Boolean deleteUserById(Long id);
	
	public Boolean updateUserById(Long Id , InventryDto inventryDTO);
}
