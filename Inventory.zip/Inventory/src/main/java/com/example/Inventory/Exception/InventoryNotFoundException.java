package com.example.Inventory.Exception;

public class InventoryNotFoundException extends RuntimeException {
public InventoryNotFoundException(){
	
}
public InventoryNotFoundException(String message){
	super(message);
}
}
