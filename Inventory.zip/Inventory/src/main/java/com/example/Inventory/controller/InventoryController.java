package com.example.Inventory.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Inventory.dto.InventryDto;
import com.example.Inventory.entity.InventryEntity;
import com.example.Inventory.response.InventryResponse;
import com.example.Inventory.service.InventoryService;


@RestController
@RequestMapping("/users")
public class InventoryController {

	@Autowired
	InventoryService inventryService;
	
	
	@PostMapping("/createinventry")
	public ResponseEntity<Object> saveUpdateInventry(@RequestBody InventryDto iventryDTO){
		return  InventryResponse.generateResponse("success", HttpStatus.OK, inventryService.saveUpdateUser(iventryDTO));
	}
	


	@GetMapping("/getAllUsers")
	public ResponseEntity<List<InventryEntity>> getUsers(){
	ResponseEntity<List<InventryEntity>> users = inventryService.getUsers();
		
		return users;
	}
	
	@DeleteMapping("/deleteUser/{id}")
	public Boolean deleteUser(@PathVariable Long id) {
		
	Boolean deleteUserById = inventryService.deleteUserById(id);
		
		
		return deleteUserById;
	}
	
	@PutMapping("/updateUser/{id}")
	public Boolean updateUser(@RequestBody InventryDto inventryDto, @PathVariable Long id) {
		
		
		return inventryService.updateUserById(id , inventryDto);
	}
	
	
	

}