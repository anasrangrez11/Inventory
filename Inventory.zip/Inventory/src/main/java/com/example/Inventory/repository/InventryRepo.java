package com.example.Inventory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Inventory.entity.InventryEntity;

public interface InventryRepo extends JpaRepository<InventryEntity , Long> {


	
	

}
