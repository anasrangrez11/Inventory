package com.example.University.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.University.Entity.University;
import com.example.University.dto.UniversityDto;

@Repository
public interface UniversityRepository extends JpaRepository<University, Long>{

	//@Query("select * from University where name= :name")
	public List<UniversityDto> getFindByName(String name);
	
}
