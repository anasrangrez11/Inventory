package com.example.University.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.University.dto.UniversityDto;
import com.example.University.repository.UniversityRepository;

@Service
public class UniversityServiceImpl implements UniversityService {

	@Autowired
	UniversityRepository universityRepo;

	// Providing the data

	@Override
	public ResponseEntity<List<UniversityDto>> getAllDetails(String name) {

		List<UniversityDto> findByName =  universityRepo.getFindByName(name);
		
		return new ResponseEntity<List<UniversityDto>>(findByName,HttpStatus.OK);
	}

}
