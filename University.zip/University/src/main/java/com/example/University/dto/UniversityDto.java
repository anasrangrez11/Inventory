package com.example.University.dto;

public class UniversityDto {

	private Long id;
    private String name;
    private Long universityContact;
    private String universityAddress;
    private Long universityRegNumber;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getUniversityContact() {
		return universityContact;
	}
	public void setUniversityContact(Long universityContact) {
		this.universityContact = universityContact;
	}
	public String getUniversityAddress() {
		return universityAddress;
	}
	public void setUniversityAddress(String universityAddress) {
		this.universityAddress = universityAddress;
	}
	public Long getUniversityRegNumber() {
		return universityRegNumber;
	}
	public void setUniversityRegNumber(Long universityRegNumber) {
		this.universityRegNumber = universityRegNumber;
	}
}
