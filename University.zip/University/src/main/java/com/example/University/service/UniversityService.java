package com.example.University.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.University.dto.UniversityDto;

public interface UniversityService {

	public ResponseEntity<List<UniversityDto>> getAllDetails(String name);
	
}
