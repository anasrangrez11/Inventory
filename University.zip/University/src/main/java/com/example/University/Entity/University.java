package com.example.University.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity

@Table(name ="university")
public class University {

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id;
	    private String name;
	    private Long universityContact;
	    private String universityAddress;
	    private Long universityRegNumber;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Long getUniversityContact() {
			return universityContact;
		}
		public void setUniversityContact(Long universityContact) {
			this.universityContact = universityContact;
		}
		public String getUniversityAddress() {
			return universityAddress;
		}
		public void setUniversityAddress(String universityAddress) {
			this.universityAddress = universityAddress;
		}
		public Long getUniversityRegNumber() {
			return universityRegNumber;
		}
		public void setUniversityRegNumber(Long universityRegNumber) {
			this.universityRegNumber = universityRegNumber;
		}
}
