package com.example.University.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.University.Entity.University;
import com.example.University.dto.UniversityDto;
import com.example.University.service.UniversityService;

@RestController
@RequestMapping("/university")
public class UniversityController {
	
	@Autowired
	UniversityService universityService;

	@GetMapping("/getUniversity/{name}")
	public ResponseEntity<List<UniversityDto>> getUniversityDetail(@PathVariable String name){
		ResponseEntity<List<UniversityDto>> allDetails = universityService.getAllDetails(name);
		return allDetails;
	}
	
}
